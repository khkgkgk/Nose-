# Delight Extras (Fabric 1.21.1)

Addon de **Farmer's Delight Refabricated** con comidas y recetas nuevas.

## Comidas
| Plato | Donde se cocina | Ingredientes |
|---|---|---|
| Tomato Rice Bowl | Olla (cuenco) | arroz cocido, tomate, cebolla |
| Stuffed Cabbage Rolls | Olla (cuenco) | 2 hojas de col, carne picada, arroz cocido |
| Pumpkin Pasta Bake | Olla (cuenco) | pasta cruda, calabaza, salsa de tomate, carne picada |
| Berry Rice Pudding | Olla (cuenco) | arroz cocido, 2 bayas dulces, azucar, huevo |
| Honey Glazed Carrots | Mesa de crafteo | botella de miel + 3 zanahorias -> 3 |
| Bacon & Egg Sandwich | Mesa de crafteo | 2 pan, bacon cocinado, huevo frito |

## Compilar
```
gradle wrapper --gradle-version 8.12   # solo la primera vez
./gradlew build
```
El .jar queda en `build/libs/`. Necesita Java 21.

## Anadir recetas con Hands on Delight
Agrega los items de ese mod en cualquier receta de `data/delight_extras/recipe/`
(usando su ID real, p. ej. `"item": "<modid>:<item>"`).
