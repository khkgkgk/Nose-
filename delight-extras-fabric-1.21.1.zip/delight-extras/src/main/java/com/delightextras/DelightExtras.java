package com.delightextras;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DelightExtras implements ModInitializer {
    public static final String MOD_ID = "delight_extras";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModItems.init();
        LOGGER.info("Delight Extras cargado: comidas nuevas para Farmer's Delight.");
    }
}
