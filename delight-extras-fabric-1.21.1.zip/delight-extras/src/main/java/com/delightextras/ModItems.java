package com.delightextras;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class ModItems {
    private ModItems() {}

    // ---- Platos en cuenco (se cocinan en la olla de Farmer's Delight) ----
    public static final Item TOMATO_RICE_BOWL = register("tomato_rice_bowl",
            new BowlFoodItem(new Item.Settings().maxCount(16).food(
                    new FoodComponent.Builder().nutrition(10).saturationModifier(0.8f)
                            .statusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 100), 1.0f)
                            .build())));

    public static final Item STUFFED_CABBAGE_ROLLS = register("stuffed_cabbage_rolls",
            new BowlFoodItem(new Item.Settings().maxCount(16).food(
                    new FoodComponent.Builder().nutrition(12).saturationModifier(0.85f)
                            .statusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 600), 1.0f)
                            .build())));

    public static final Item PUMPKIN_PASTA_BAKE = register("pumpkin_pasta_bake",
            new BowlFoodItem(new Item.Settings().maxCount(16).food(
                    new FoodComponent.Builder().nutrition(13).saturationModifier(0.9f)
                            .statusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 600), 1.0f)
                            .build())));

    public static final Item BERRY_RICE_PUDDING = register("berry_rice_pudding",
            new BowlFoodItem(new Item.Settings().maxCount(16).food(
                    new FoodComponent.Builder().nutrition(8).saturationModifier(0.7f)
                            .statusEffect(new StatusEffectInstance(StatusEffects.SPEED, 900), 1.0f)
                            .build())));

    // ---- Comidas rapidas (crafteo normal) ----
    public static final Item HONEY_GLAZED_CARROTS = register("honey_glazed_carrots",
            new Item(new Item.Settings().food(
                    new FoodComponent.Builder().nutrition(6).saturationModifier(0.8f)
                            .statusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 600), 1.0f)
                            .build())));

    public static final Item BACON_EGG_SANDWICH = register("bacon_egg_sandwich",
            new Item(new Item.Settings().food(
                    new FoodComponent.Builder().nutrition(9).saturationModifier(0.8f).build())));

    // ---- Pestana creativa ----
    public static final ItemGroup GROUP = Registry.register(Registries.ITEM_GROUP,
            Identifier.of(DelightExtras.MOD_ID, "main"),
            FabricItemGroup.builder()
                    .icon(() -> new ItemStack(TOMATO_RICE_BOWL))
                    .displayName(Text.translatable("itemGroup.delight_extras.main"))
                    .entries((context, entries) -> {
                        entries.add(TOMATO_RICE_BOWL);
                        entries.add(STUFFED_CABBAGE_ROLLS);
                        entries.add(PUMPKIN_PASTA_BAKE);
                        entries.add(BERRY_RICE_PUDDING);
                        entries.add(HONEY_GLAZED_CARROTS);
                        entries.add(BACON_EGG_SANDWICH);
                    })
                    .build());

    private static Item register(String name, Item item) {
        return Registry.register(Registries.ITEM, Identifier.of(DelightExtras.MOD_ID, name), item);
    }

    /** Fuerza la carga de la clase (y con ella el registro de items). */
    public static void init() {}
}
